

#import "EpubContent.h"

@implementation EpubContent

@synthesize _manifest;
@synthesize _spine;


@end
